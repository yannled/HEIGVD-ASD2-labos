#include "GraphFromImage.h"

namespace ASD2 {

    GraphFromImage::GraphFromImage(const bitmap_image& i) : image(i) { 
        /* A IMPLEMENTER */
    }
    
    GraphFromImage::Iterable GraphFromImage::adjacent(int v) const {
        /* A IMPLEMENTER */
    }
    
    int GraphFromImage::idx(int x, int y) const {
        /* A IMPLEMENTER */
    }

    int GraphFromImage::x(int idx) const {
        /* A IMPLEMENTER */
    }

    int GraphFromImage::y(int idx) const {
        /* A IMPLEMENTER */
    }
    
    int GraphFromImage::V() const {
        /* A IMPLEMENTER */
    }

}