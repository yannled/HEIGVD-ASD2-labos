/*============================================================================
 * Name        : ArbreHuffmanBranche.cpp
 * Date        : 18 juil. 2013
 * Author      : Fabien Dutoit
 * Version     : 1.0
 *
 * Description : Classe représentant un arbre de Huffman
 *               Implémentation d'une branche contenant deux sous arbres
 *============================================================================*/

#ifndef ARBREHUFFMANBRANCHE_CPP
#define	ARBREHUFFMANBRANCHE_CPP

#include <vector>

#include "ArbreHuffmanBranche.h"

/*
 * Constructeur d'un arbre vide
 */
ArbreHuffmanBranche::ArbreHuffmanBranche() {
    /*A IMPLEMENTER*/
}
/*
 * But: Vérifie si le caractère appartient à l'arbre
 * Entrée: Le caractère dont la présence doit être vérifiée
 * Sortie: Booléen indiquant la présence
 */
bool ArbreHuffmanBranche::contient(char caracter) {
    /*A IMPLEMENTER*/
}

/*
 * But: Obtenir la fréquence des caractères contenu dans cet arbre
 * Exception: SousArbreVide si au moins un des sous-arbres est non-défini
 */
long ArbreHuffmanBranche::getFrequence() const {
    /*A IMPLEMENTER*/
}

/*
 * But: Setter une valeur de fréquence particulière
 * Entrée: valeur de la fréquence
 * Exception: OperationUniquementPossibleSurUneFeuille si appliqué sur une branche
 */
void ArbreHuffmanBranche::setFrequence(long freq){
    /*A IMPLEMENTER*/
}

/*
 * But: Opération permettant d'incrémenter la fréquence d'un élément
 * Exception: OperationUniquementPossibleSurUneFeuille si appliqué sur une branche
 */
void ArbreHuffmanBranche::incrementeFrequence() {
    /*A IMPLEMENTER*/
}

/*
 * But: Opérations permettant d'accrocher un sous-arbre à gauche ou a droite de l'arbre courant
 * Exception: OperationUniquementPossibleSurUneBranche si appliqué sur une feuille
 */
void ArbreHuffmanBranche::accrocheGauche(ArbreHuffman* sousArbre) {
    /*A IMPLEMENTER*/
}

void ArbreHuffmanBranche::accrocheDroite(ArbreHuffman* sousArbre) {
    /*A IMPLEMENTER*/
}

/*
 * But: Sérialisation de l'arbre
 * Exception: SousArbreVide si au moins un des sous-arbres est non-défini
 */
std::string ArbreHuffmanBranche::toString() {
    if(gauche == nullptr || droite == nullptr){
        throw SousArbreVide();
    }
    
    std::stringstream sstrings;
    sstrings << "(" << gauche->toString() << ";" << droite->toString() << ")";
    return sstrings.str();
}

/*
 * But: Compresser un caractère
 * Entrée: Le caractère à encoder
 * Sortie: Un vecteur représentant les bits correspondant au caractère
 * Exception: SousArbreVide si au moins un des sous-arbres est non-défini
 *            ProblemeEncodage en cas d'erreur d'encodage (caractère manquant pas ex.)
 */
std::vector<bool> ArbreHuffmanBranche::compresse(char caractere)
{
    /*A IMPLEMENTER*/
}

/*
 * But: Décompresser un caractère
 * Entrée: Un pointeur sur le vecteur de bits à utiliser
 *         Les bits utilisés seront consommés, en cas de problème (par ex.: BitStreamTropCourt) le vecteur ne doit pas être modifié
 * Sortie: Le caractère décompressé
 * Exceptions: SousArbreVide si au moins un des sous-arbres est non-défini
 *             BitStreamTropCourt si le vecteur de bits est trop court pour déterminer un unique caractère             
 */
char ArbreHuffmanBranche::decompresse(std::vector<bool>* bits) {
    /*A IMPLEMENTER*/
}

/*
 * Destructeur
 * Détruit récursivement tout l'arbre
 */
ArbreHuffmanBranche::~ArbreHuffmanBranche() {
    /*A IMPLEMENTER*/
}

#endif	/* ARBREHUFFMANBRANCHE_CPP */
